package com.javasampleapproach.multipartfile.model;

public class View {
	public interface FileInfo {}
}
