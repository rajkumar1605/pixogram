package com.pixogram.PixoGram.service;

import java.util.Optional;

import com.pixogram.PixoGram.model.User;

public interface UserService {

	User createUser(User user);

	User loginUser(String email, String password);

	User checkUsername(String username);

	Optional<User> getUserById(long userId);

}
