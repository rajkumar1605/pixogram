package com.pixogram.PixoGram.service;

import java.util.List;

import com.pixogram.PixoGram.model.Posts;

public interface PostsService {

	void save(Posts post);

	List<Posts> findAllPosts();

}
