import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { Router } from '@angular/router';
import { User } from '../user/user';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: User = new User();
  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
  }

  onSubmit(form: NgForm) {
    this.user.name = form.value.name
    this.user.password = form.value.password
    this.userService.checkLogin(this.user).subscribe(
      (data: number) => {

        if (data == 0) {
          window.alert("Check your credentials")
        } else {
          window.alert("login successful")
          console.log(data)
          localStorage.setItem("userId",
            data.toString());
        }
      },
      error => console.log(error)
    )
  }

}
