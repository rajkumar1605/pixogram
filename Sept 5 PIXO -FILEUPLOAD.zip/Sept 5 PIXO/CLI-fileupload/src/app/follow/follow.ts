import { User } from '../user/user';

export class Follow {
    public  
    id:number;
    userid:User;
    followid:User;
}
