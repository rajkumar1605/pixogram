import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private user_url = "http://localhost:9531/user";

  constructor(private http: HttpClient) { }

  signupUser(user: User): Observable<User> {
    return this.http.post<User>(`${this.user_url}/create`, user)
  }

  checkLogin(value:User): Observable<number> {
    return this.http.post<number>(`${this.user_url}/login`,value)
  }

  checkUsername(name:String):Observable<number>{
    return this.http.get<number>(`${this.user_url}/checkUsername/${name}`)
  }

  getUserDetail(userId:number):Observable<User>{
    return this.http.get<User>(`${this.user_url}/${userId}`)
  }
}
