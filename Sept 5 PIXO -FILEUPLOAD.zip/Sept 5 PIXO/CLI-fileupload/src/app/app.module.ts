import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule  } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { UploadmediaComponent } from './post/uploadmedia/uploadmedia.component';
import { SingleMediaComponent } from './post/uploadmedia/single-media/single-media.component';
import { MultipleMediaComponent } from './post/uploadmedia/multiple-media/multiple-media.component';
import { MyMediaComponent } from './my-media/my-media.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SignupComponent,
    LoginComponent,
    UploadmediaComponent,
    SingleMediaComponent,
    MultipleMediaComponent,
    MyMediaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'',component:LoginComponent},
      {path:'signup',component:SignupComponent},
      {path:'uploadMedia',component:UploadmediaComponent,children:([
        {path:'singleMedia',component:SingleMediaComponent},
        {path:'multipleMedia',component:MultipleMediaComponent}
      ])},
      {path:"myMedia",component:MyMediaComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
