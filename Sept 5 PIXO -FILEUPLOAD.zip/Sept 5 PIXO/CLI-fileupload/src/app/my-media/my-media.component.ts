import { Component, OnInit } from '@angular/core';
import { User } from '../user/user';
import { Router } from '@angular/router';
import { UserService } from '../user/user.service';
import { PostService } from '../post/post.service';
import { Post } from '../post/post';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-my-media',
  templateUrl: './my-media.component.html',
  styleUrls: ['./my-media.component.css']
})
export class MyMediaComponent implements OnInit {

  userId
  user: User
  post:Observable<Post[]>

  constructor(private router:Router,private userService:UserService,private postService:PostService) { }


  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    } else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
        },
        error => console.log(error)
      )

      this.post=this.postService.getPosts()
    }
  }

  createUser(user: User) {
    this.user = user
  }

}
