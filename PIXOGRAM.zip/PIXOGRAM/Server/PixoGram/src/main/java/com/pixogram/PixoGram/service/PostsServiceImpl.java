package com.pixogram.PixoGram.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.PixoGram.model.Posts;
import com.pixogram.PixoGram.repository.PostsRepository;

@Service
public class PostsServiceImpl implements PostsService {

	@Autowired
	PostsRepository repository;

	@Override
	public void save(Posts post) {
		repository.save(post);

	}

	@Override
	public List<Posts> findAllPosts() {
		return repository.findAll();
	}

	@Override
	public List getAllPostsByUserId(long userId) {
		return repository.getAllPostsByUserId(userId);
	}

	@Override
	public Optional<Posts> getAllPostsByPostId(long postId) {
		return repository.findById(postId);
	}

	@Override
	public void updateLike(Posts like) {
		repository.save(like);
		
	}

}
