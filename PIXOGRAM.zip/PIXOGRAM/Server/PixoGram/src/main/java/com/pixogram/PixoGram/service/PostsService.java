package com.pixogram.PixoGram.service;

import java.util.List;
import java.util.Optional;

import com.pixogram.PixoGram.model.Posts;

public interface PostsService {

	void save(Posts post);

	List<Posts> findAllPosts();

	List getAllPostsByUserId(long userId);

	Optional<Posts> getAllPostsByPostId(long postId);

	void updateLike(Posts like);

}
