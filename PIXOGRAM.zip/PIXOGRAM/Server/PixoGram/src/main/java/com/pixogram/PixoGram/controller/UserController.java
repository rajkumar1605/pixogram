package com.pixogram.PixoGram.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.PixoGram.model.User;
import com.pixogram.PixoGram.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService service;

	// this is used to create/signup new user
	@PostMapping(value = "/create")
	public User createUser(@RequestBody User user) {
		User created_user = service.createUser(user);
		return created_user;
	}
	
	// this is used for User Login
	@PostMapping(value = "/login")
	public long loginUser(@RequestBody User user) {
		System.out.println("checking user login...");
		User logged_user = service.loginUser(user.getName(), user.getPassword());
		System.out.println(logged_user);
		if (logged_user == null) {
			System.out.println("wrong credentials");
			return 0;
		}
		return logged_user.getId();
	}
	
	//this is used for fetching user by id
	@GetMapping(value="/{userId}")
	public Optional<User> getUserById(@PathVariable("userId") int userId) {
		Optional<User> user=service.getUserById(userId);
		return user;
	}
	
	//this is used to check whether the username is already taken/not
	@GetMapping(value="/checkUsername/{name}")
	public long checkUsername(@PathVariable("name") String username) {
		System.out.println("fetching user by id ");
		User res=service.checkUsername(username);
		if(res==null) {
			return 1;
		}
		return 0;
	}
	
	//this is used to fetch all the users
	@GetMapping(value="/all")
	public List<User> getAllUsers(){
		System.out.println("fetching all the users..");
		List<User> user=new ArrayList<User>();
		service.getAllUsers().forEach(user::add);
		return user;
	}
	
	@GetMapping(value="search/{name}")
	public List<User> searchUser(@PathVariable("name") String name){
		System.out.println("fetching user by search option");
		List<User> user=new ArrayList<>();
		service.searchUser(name).forEach(user::add);
		return user;
	}
	
	//update the user details
	@PutMapping(value="/update/{id}")
	public User updateUser(@PathVariable("id") long id, @RequestBody User user) {
		System.out.println("user updating...");
		User newUser=new User();
		System.out.println(user.getId());
		newUser.setId(id);
		newUser.setEmail(user.getEmail());
		newUser.setName(user.getName());
		newUser.setPassword(user.getPassword());
		
		User updated_user=service.updateUser(newUser);
		return updated_user;
	}
}
