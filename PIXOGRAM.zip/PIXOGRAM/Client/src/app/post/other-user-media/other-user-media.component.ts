import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user/user';
import { Observable } from 'rxjs';
import { Post } from '../post';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { UserService } from 'src/app/user/user.service';
import { PostService } from '../post.service';

@Component({
  selector: 'app-other-user-media',
  templateUrl: './other-user-media.component.html',
  styleUrls: ['./other-user-media.component.css']
})
export class OtherUserMediaComponent implements OnInit {
  userId
  user: User
  post:  Post[]
  otherUserId: number
  valid:boolean=false
  constructor(private router: Router, private userService: UserService, private postService: PostService, private route: ActivatedRoute) { }


  ngOnInit() {

    this.otherUserId = this.route.snapshot.params['id'];
    console.log(this.otherUserId)
    this.route.params.subscribe(
      (id: Params) => {
        this.otherUserId = +id['id']
      },
      error => console.log(error)
    )

    this.userId = localStorage.getItem("userId");

    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    } else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
          this.initOtherUserPosts();
        },
        error => console.log(error)
      )

    }
 
  }

  createUser(user: User) {
    this.user = user
  }

  initOtherUserPosts() {
    
    this.postService.getPostsById(this.otherUserId).subscribe(
      (post:Post[])=>{
        this.createPost(post)
      }
    )

   
  }

  createPost(post:Post[]){
    this.post=post
    if(this.post.length==0){ 
      this.valid=false
      return
    }
    this.valid=true
  }

}
