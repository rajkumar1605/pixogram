import { Injectable } from '@angular/core';
import { User } from '../user/user';
import { HttpClient } from '@angular/common/http';
import { Block } from './block';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BlockService {

  private block_url = "http://localhost:9531/block";

  constructor(private http: HttpClient) { }

  block(block: Block): Observable<number> {
    return this.http.post<number>(`${this.block_url}/block`, block)
  }

  getAllBlockedUsers():Observable<Block[]>{
    return this.http.get<Block[]>(`${this.block_url}/all`)
  }

  getAllBlockedUsersByUserId(userId:number):Observable<Block[]>{
    return this.http.get<Block[]>(`${this.block_url}/${userId}`)
  }

  unBlock(id:number):Observable<any>{
    return this.http.delete(`${this.block_url}/${id}`,{responseType:'text'})
  }
}
