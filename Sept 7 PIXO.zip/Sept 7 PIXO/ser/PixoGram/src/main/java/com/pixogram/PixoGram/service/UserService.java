package com.pixogram.PixoGram.service;

import java.util.List;
import java.util.Optional;

import com.pixogram.PixoGram.model.User;

public interface UserService {

	User createUser(User user);

	User loginUser(String email, String password);

	User checkUsername(String username);

	Optional<User> getUserById(long userId);

	List<User> getAllUsers();

	List<User> searchUser(String name);

	User updateUser(User newUser);

}
