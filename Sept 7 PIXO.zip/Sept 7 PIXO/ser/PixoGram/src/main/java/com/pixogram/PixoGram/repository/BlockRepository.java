package com.pixogram.PixoGram.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pixogram.PixoGram.model.Block;

public interface BlockRepository extends JpaRepository<Block, Long> {

	@Query("select b from Block b where b.userid.id= :userId")
	List<Block> getBlockedByUserId(@Param("userId") long id);

}
