import { Component, OnInit } from '@angular/core';
import { UserService } from '../../user.service';
import { Router } from '@angular/router';
import { User } from '../../user';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  userId
  currentUser: User
  showView:boolean=false
  username:String
  validPass: boolean;
  validUsername: boolean = true;
  user:User=new User()
  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    }
    else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
        },
        error => console.log(error)
      )
    }
  }

  createUser(user: User) {
    this.currentUser = user
    this.showView=true
    this.username=this.currentUser.name
  }

  
  checkUserName(name: String) {
    this.userService.checkUsername(name).subscribe(
      (data: number) => {
        if(this.username==name){
          this.validUsername = true;
        }else{
        if (data == 0) {
          console.log("already taken")
          this.validUsername = false;
        }
        if (data == 1) {
          console.log("valid username")
          this.validUsername = true;
        }
      }
      },
      error => console.log(error)
    )
  }

  onPasswordCheck(password: String, rpassword: String) {
    if (password === rpassword) {

      this.validPass = false
    } else {

      this.validPass = true
    }
  }

  onSubmit(form:NgForm){
    this.user.id=this.userId
    this.user.name = form.value.name;
    this.user.email = form.value.email;
    this.user.password = form.value.password;
    this.userService.updateUser(this.user,this.userId).subscribe(
      (data: User) => {
        console.log(data)
        this.ngOnInit()
      },
      error => console.log(error)
    )
  }
}
