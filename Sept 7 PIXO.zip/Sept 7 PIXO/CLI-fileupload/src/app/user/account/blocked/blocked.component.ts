import { Component, OnInit } from '@angular/core';
import { BlockService } from 'src/app/block/block.service';
import { Router } from '@angular/router';
import { UserService } from '../../user.service';
import { User } from '../../user';
import { Block } from 'src/app/block/block';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-blocked',
  templateUrl: './blocked.component.html',
  styleUrls: ['./blocked.component.css']
})
export class BlockedComponent implements OnInit {
userId
user:User
block:Observable<Block[]>
  constructor(private blockService:BlockService,private router:Router,private userService:UserService) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    }
    else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
          this.initBlock()
        },
        error => console.log(error)
      )
    }
  }

  createUser(user:User){
    this.user=user;
  }

  initBlock(){
    this.block=this.blockService.getAllBlockedUsersByUserId(this.userId)
  }

  onUnBlock(id:number){
this.blockService.unBlock(id).subscribe(
  (data)=>{
    console.log(data)
    this.ngOnInit()
  },
  error=>console.log(error)
)
  }

}
