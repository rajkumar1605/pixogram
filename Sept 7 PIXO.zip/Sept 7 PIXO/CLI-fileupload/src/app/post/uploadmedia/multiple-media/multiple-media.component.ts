import { Component, OnInit } from '@angular/core';

import { HttpEventType, HttpResponse } from '@angular/common/http';
import { PostService } from '../../post.service';
import { Router } from '@angular/router';
import { User } from 'src/app/user/user';
import { UserService } from 'src/app/user/user.service';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-multiple-media',
  templateUrl: './multiple-media.component.html',
  styleUrls: ['./multiple-media.component.css']
})
export class MultipleMediaComponent implements OnInit {
  fileData: File[] = [];
  fileModel: { title: String, description: String }[] = []
  title: String
  description: String
  tags: String;
  userId
  user: User
  cnt=0

  progress: { percentage: number } = { percentage: 0 };
  constructor(private postService: PostService, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    } else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
        },
        error => console.log(error)
      )
    }
  }

  createUser(user: User) {
    this.user = user
  }

  selectFile(event) {
    this.fileData.push(<File>event.target.files[0])
    console.log(this.fileData)
    
  }

  onAdd() {
    let description = this.description
    let title = this.title
    this.fileModel.push({ title, description })
    this.description = undefined
    this.title = undefined
    console.log(this.fileModel)
    if(this.cnt==0){
      this.cnt++
    alert("Note!!!"+"\nFor Adding more image/post : please enter the title and description in same input field and add new image in same upload image button")
    }
  }

  onSubmit() {
    let i = 0
   
    let description = this.description
    let title = this.title
    this.fileModel.push({ title, description })
    this.description = undefined
    this.title = undefined
    console.log(this.fileModel)
    let len=this.fileData.length
    console.log(this.fileModel[1].title)
    this.progress.percentage = 0;
    for (var fileData of this.fileData) {
      this.postService.uploadPost(this.userId, fileData, this.fileModel[i].title, this.fileModel[i].description).subscribe(event => {
        if (event.type === HttpEventType.UploadProgress) {
          this.progress.percentage = Math.round(100 * event.loaded / event.total);
        } else if (event instanceof HttpResponse) {
          console.log('File is completely uploaded!');
         
          console.log(i)
          if (i == len) {
            this.router.navigate(['/homepage'])
          }
        }
      }, error => console.log(error)
      );
      i++
    }

    this.fileData = undefined;
  }
}

