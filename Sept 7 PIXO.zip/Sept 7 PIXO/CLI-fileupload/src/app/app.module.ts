import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule  } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { UploadmediaComponent } from './post/uploadmedia/uploadmedia.component';
import { SingleMediaComponent } from './post/uploadmedia/single-media/single-media.component';
import { MultipleMediaComponent } from './post/uploadmedia/multiple-media/multiple-media.component';
import { MyMediaComponent } from './post/my-media/my-media.component';
import { MediaDetailsComponent } from './post/media-details/media-details.component';
import { HomepageComponent } from './homepage/homepage.component';
import { FollowingComponent } from './follow/following/following.component';
import { FollowersComponent } from './follow/followers/followers.component';
import { FollowComponent } from './follow/follow.component';
import { AccountComponent } from './user/account/account.component';
import { NewsfeedComponent } from './user/account/newsfeed/newsfeed.component';
import { BlockedComponent } from './user/account/blocked/blocked.component';
import { UpdateComponent } from './user/account/update/update.component';
import { SearchComponent } from './user/account/search/search.component';
import { OtherUserMediaComponent } from './post/other-user-media/other-user-media.component';
 

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SignupComponent,
    LoginComponent,
    UploadmediaComponent,
    SingleMediaComponent,
    MultipleMediaComponent,
    MyMediaComponent,
    MediaDetailsComponent,
    HomepageComponent,
    FollowingComponent,
    FollowersComponent,
    FollowComponent,
    AccountComponent,
    NewsfeedComponent,
    BlockedComponent,
    UpdateComponent,
    SearchComponent,
    OtherUserMediaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'',component:LoginComponent,pathMatch:"full"},
      {path:'signup',component:SignupComponent},
      {path:'uploadMedia',component:UploadmediaComponent,children:([
        {path:'singleMedia',component:SingleMediaComponent},
        {path:'multipleMedia',component:MultipleMediaComponent}
      ])},
      {path:"myMedia",component:MyMediaComponent},
      {path:"media/:id",component:MediaDetailsComponent},
      {path:"homepage",component:HomepageComponent},
      {path:"followhomepage",component:FollowComponent,children:([
        {path:'',component:FollowingComponent,pathMatch:"full"},
        {path:'following',component:FollowingComponent},
        {path:'followers',component:FollowersComponent}
      ])},
      {path:"account",component:AccountComponent,children:([
        {path:'',component:NewsfeedComponent,pathMatch:"full"},
        {path:"newsfeed",component:NewsfeedComponent},
        {path:"blocked",component:BlockedComponent},
        {path:"update",component:UpdateComponent},
        {path:"search",component:SearchComponent}
      ])},
      {path:'otherUser/:id',component:OtherUserMediaComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
