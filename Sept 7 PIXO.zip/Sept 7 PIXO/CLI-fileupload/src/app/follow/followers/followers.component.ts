import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user/user.service';
import { Router } from '@angular/router';
import { FollowService } from '../follow.service';
import { BlockService } from 'src/app/block/block.service';
import { User } from 'src/app/user/user';
import { Follow } from '../follow';
import { Block } from 'src/app/block/block';

@Component({
  selector: 'app-followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {

  userId;
  block: Block = new Block()
  currentUser: User
  followers: Follow[] = []
  blockedUsers: Block[] = []
  filteredFollowers: Follow[] = []

  constructor(private userService: UserService, private router: Router, private followService: FollowService, private blockService: BlockService) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    }
    else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
          this.initFollowers()
          
        },
        error => console.log(error)
      )
    }
  }

  createUser(user: User) {
    this.currentUser = user;
  }

  initFollowers() {
    this.followService.getAllFollowersByUserId(this.userId).subscribe(
      (followers: Follow[]) => {
        this.createFollowers(followers)
        this.initBlockedUsers()
      }
    )
  }
  initBlockedUsers() {
    this.blockService.getAllBlockedUsersByUserId(this.userId).subscribe(
      (blockedUser: Block[]) => {
        this.createBlockedUser(blockedUser)
      }
    )

  }

  createFollowers(followers: Follow[]) {
    this.followers = followers;
  }
  createBlockedUser(blocked: Block[]) {
    this.blockedUsers = blocked;

    let flag = 0;

    if (this.blockedUsers.length == 0) {
      this.filteredFollowers.push(... this.followers)
    } else {

      for (var user of this.followers) {
        flag = 0
        for (var block of this.blockedUsers) {
          if (user.userid.id == block.blockid.id && user.userid.id != this.currentUser.id) {
            flag++;
          }
        }
        if (flag == 0 && user.userid.id != this.currentUser.id) {
          this.filteredFollowers.push(user)
        }
      }
    }
  }

  onBlock(blockUser: User) {
    this.block.userid = this.currentUser
    this.block.blockid = blockUser
    this.blockService.block(this.block).subscribe(
      (data) => {
        this.filteredFollowers = []
        this.ngOnInit()
      },
      error => console.log(error)
    )
  }

}
