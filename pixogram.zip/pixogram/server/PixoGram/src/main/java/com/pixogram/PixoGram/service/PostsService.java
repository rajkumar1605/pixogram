package com.pixogram.PixoGram.service;

public interface PostsService {

}
