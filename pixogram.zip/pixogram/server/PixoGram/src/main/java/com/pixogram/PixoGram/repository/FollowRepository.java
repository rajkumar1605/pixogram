package com.pixogram.PixoGram.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pixogram.PixoGram.model.Follow;

public interface FollowRepository extends JpaRepository<Follow,Long> {

}
