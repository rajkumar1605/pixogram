package com.pixogram.PixoGram.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.pixogram.PixoGram.service.PostsService;

public class PostsController {

	@Autowired
	PostsService service;
}
