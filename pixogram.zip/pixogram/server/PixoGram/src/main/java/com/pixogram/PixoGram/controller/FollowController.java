package com.pixogram.PixoGram.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.pixogram.PixoGram.service.FollowService;

public class FollowController {

	@Autowired
	FollowService service;
	
}
