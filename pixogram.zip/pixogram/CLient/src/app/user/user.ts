export class User {
    public
    id: number;
    name: String;
    email: String;
    password: String;
}
