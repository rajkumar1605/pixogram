import { User } from '../user/user';

export class Block {
    public  
        id:number;
        userid:User;
        blockid:User;

}
