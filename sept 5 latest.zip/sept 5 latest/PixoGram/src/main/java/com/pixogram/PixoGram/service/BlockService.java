package com.pixogram.PixoGram.service;

 
public interface BlockService {

}
