package com.pixogram.PixoGram.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.pixogram.PixoGram.model.User;
import com.pixogram.PixoGram.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository repository;
	
	@Override
	public User createUser(User user) {
		return repository.save(new User(user.getName(),user.getEmail(),user.getPassword()));
	}

	@Override
	public User loginUser(String name, String password) {
		return repository.findByEmailAndPass(name,password);
	}

	@Override
	public User checkUsername(String username) {
		return repository.findByName(username);
	}

	@Override
	public Optional<User> getUserById(long userId) {
		return repository.findById(userId);
	}

	@Override
	public List<User> getAllUsers() {
		return repository.findAll();
	}

	@Override
	public List<User> searchUser(String name) {
		return repository.searchUser(name);
	}

}
