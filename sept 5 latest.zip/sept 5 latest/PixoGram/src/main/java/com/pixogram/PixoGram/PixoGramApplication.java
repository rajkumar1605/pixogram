package com.pixogram.PixoGram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PixoGramApplication {

	public static void main(String[] args) {
		SpringApplication.run(PixoGramApplication.class, args);
	}

}
