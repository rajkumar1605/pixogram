package com.pixogram.PixoGram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.PixoGram.model.Follow;
import com.pixogram.PixoGram.model.User;
import com.pixogram.PixoGram.repository.FollowRepository;

@Service
public class FollowServiceImpl implements FollowService {

	@Autowired
	FollowRepository repository;
	
	@Override
	public List<Follow> getAllFollows() {
		return repository.findAll();
	}

	@Override
	public void follow(Follow followUser) {
		repository.save(followUser);		
	}

	@Override
	public void unfollow(long id) {
		repository.deleteById(id);
		
	}

	 

}
