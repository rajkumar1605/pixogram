package com.pixogram.PixoGram.service;

import java.util.List;

import com.pixogram.PixoGram.model.Follow;
import com.pixogram.PixoGram.model.User;

public interface FollowService {

	List<Follow> getAllFollows();
 

	void follow(Follow followUser);


	void unfollow(long id);

}
