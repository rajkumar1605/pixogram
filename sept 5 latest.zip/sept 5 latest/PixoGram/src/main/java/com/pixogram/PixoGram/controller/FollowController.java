package com.pixogram.PixoGram.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.PixoGram.model.Follow;
import com.pixogram.PixoGram.model.User;
import com.pixogram.PixoGram.service.FollowService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/follow")
public class FollowController {

	@Autowired
	FollowService service;
	
	//this is used to fetch all the follows
	@GetMapping(value="/all")
	public List<Follow> getAllFollows(){
		System.out.println("fetching all the follow details");
		List<Follow> follow=new ArrayList<Follow>();
		service.getAllFollows().forEach(follow::add);
		return follow;
	}
	
	//this is used to send follow req
	@PostMapping(value="/follow")
	public int followUser(@RequestBody Follow followUser) {
		System.out.println("making follow req");
		service.follow(followUser);
		return 1;
	}
	
	//this is to unfollow
	@DeleteMapping(value="/delete/{Id}")
	public String unFollowUser(@PathVariable("Id") long id) {
		System.out.println("unfollowing the user");
		service.unfollow(id);
		return "User has unfollowed";
	}
	
}
