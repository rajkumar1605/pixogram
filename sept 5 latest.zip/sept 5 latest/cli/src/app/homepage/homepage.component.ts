import { Component, OnInit } from '@angular/core';
import { User } from '../user/user';
import { Observable } from 'rxjs';
import { Post } from '../post/post';
import { Router } from '@angular/router';
import { UserService } from '../user/user.service';
import { PostService } from '../post/post.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  userId
  user: User
  post:Observable<Post[]>

  constructor(private router:Router,private userService:UserService,private postService:PostService) { }
  
  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    } else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
        },
        error => console.log(error)
      )

      this.post = this.postService.getPosts()
    }
  }

  createUser(user: User) {
    this.user = user
  }
}
