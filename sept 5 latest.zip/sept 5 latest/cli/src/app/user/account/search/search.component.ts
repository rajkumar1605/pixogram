import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../../user.service';
import { User } from '../../user';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { FollowService } from 'src/app/follow/follow.service';
import { Follow } from 'src/app/follow/follow';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  showsearch: boolean = false
  user: User[]
  filteredUser:User[]=[]
  currentUser: User
  searchUser: Observable<User[]>
  userFollows: Follow[]
  follow: Follow = new Follow()
  userId
  constructor(private userService: UserService, private router: Router, private followService: FollowService) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    }
    else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
        },
        error => console.log(error)
      )
    }
    this.searchInit();
  }

  createUser(user: User) {
    this.currentUser = user
  }

  searchInit() {
   this.userService.getAllUsers().subscribe(
     (user:User[])=>{
       this.initAllUserList(user)
     }
   )
    this.followService.getAllFollows().subscribe(
      (data:Follow[])=>{
        this.initAllFollows(data)
      }
    );

       

  }

  initAllUserList(user:User[]){
    this.user=user;
  }

  initAllFollows(data:Follow[]){
    this.userFollows=data

    for(var user of this.user){
      for(var follow of this.userFollows)
      {
        if(this.currentUser.id!=follow.userid.id && user.id!=follow.followid.id){
        
            this.filteredUser.push(user)
          
        }
      }
    } 
    console.log(this.filteredUser)
  }

  onSearch(form: NgForm) {
    this.searchUser = this.userService.getUserByName(form.value.search);
    this.showsearch = true
  }

  onFollow(followuser: User) {


    this.follow.userid = this.currentUser
    this.follow.followid = followuser
    this.followService.follows(this.follow).subscribe(
      (data) => {
        console.log(data)
        this.searchInit()
      },
      error => console.log(error)
    )

  }

  onUnfollow(unfollowuser: User) {
    this.followService.unFollow(unfollowuser.id).subscribe(
      (data) => {
        this.searchInit()
      },
      error => console.log(error)
    )
  }

}
