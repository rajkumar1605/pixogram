package com.pixogram.PixoGram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.PixoGram.model.Follow;
import com.pixogram.PixoGram.model.User;
import com.pixogram.PixoGram.repository.FollowRepository;

@Service
public class FollowServiceImpl implements FollowService {

	@Autowired
	FollowRepository repository;
	
	@Override
	public List<Follow> getAllFollows() {
		return repository.findAll();
	}

	@Override
	public void follow(Follow followUser) {
		repository.save(new Follow(followUser.getUserid(),followUser.getFollowid()));		
	}

	@Override
	public void unfollow(long id) {
		repository.deleteById(id);
		
	}

	@Override
	public List<Follow> getFollowers(long id) {
		return repository.getFollowers(id);
	}

	@Override
	public List<Follow> getFollowing(long id) {
		return repository.getFollowing(id);
	}

	 

}
