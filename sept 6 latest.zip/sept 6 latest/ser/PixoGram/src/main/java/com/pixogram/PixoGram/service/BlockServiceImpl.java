package com.pixogram.PixoGram.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.PixoGram.model.Block;
import com.pixogram.PixoGram.repository.BlockRepository;

@Service
public class BlockServiceImpl implements BlockService {

	@Autowired
	BlockRepository repository;
	
	@Override
	public List<Block> getAllBlocks() {
		return repository.findAll();
	}

	@Override
	public Block blockUser(Block block) {
		return repository.save(new Block(block.getUserid(),block.getBlockid()));
	}

	@Override
	public List<Block> getBlockedByUserId(long id) {
		return repository.getBlockedByUserId(id);
	}

	@Override
	public void unBlock(long id) {
		  repository.deleteById(id);
		
	}

}
