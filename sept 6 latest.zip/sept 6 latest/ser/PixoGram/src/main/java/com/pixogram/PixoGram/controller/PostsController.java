package com.pixogram.PixoGram.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.pixogram.PixoGram.model.Posts;
import com.pixogram.PixoGram.model.User;
import com.pixogram.PixoGram.service.PostsService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(value = "/post")
public class PostsController {

	@Autowired
	PostsService service;

	// this is used to upload the image
	@PostMapping(value = "/upload")
	public String uploadMultipartFile(@RequestParam("user") User user, @RequestParam("file") MultipartFile file,
			@RequestParam("title") String title, @RequestParam("desc") String description) {
		try {

			Posts post = new Posts(user, file.getBytes(), title, description);
			service.save(post);
			return "File uploaded successfully! -> filename = " + file.getOriginalFilename();
		} catch (Exception e) {
			return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
		}
	}

	// this is used to fetch all images
	@GetMapping(value = "/all")
	public List getAllPosts() {
		System.out.println("fetching all posts");
		List<Posts> posts = new ArrayList<Posts>();
		service.findAllPosts().forEach(posts::add);
		return posts;
	}

	// this is used to fetch all images by UserId
	@GetMapping(value = "/{userId}")
	public List getAllPostsByUserId(@PathVariable("userId") long userId) {
		System.out.println("fetching all posts by Userid");
		List<Posts> posts = new ArrayList<Posts>();
		posts = service.getAllPostsByUserId(userId);
		return posts;
	}

	// this is used to fetch all images by UserId
	@GetMapping(value = "/post/{postId}")
	public Optional<Posts> getAllPostsByPostId(@PathVariable("postId") long postId) {
		System.out.println("fetching all posts by postId");
		Optional<Posts> post = service.getAllPostsByPostId(postId);
		System.out.println(post);
		return post;
	}
	
	//like the post
	@PutMapping(value="/like/{id}")
	public String likePost(@PathVariable("id") long id) {
		System.out.println("like enabled");
		Optional<Posts> post=service.getAllPostsByPostId(id);
		Posts like=post.get();
		long a=like.getLiked();
		like.setLiked(a+1);
		service.updateLike(like);
		return "Liked the post";
	}
	
	//unlike the post
	@PutMapping(value="/unlike/{id}")
	public String unlikePost(@PathVariable("id") long id) {
		System.out.println("unlike the post");
		Optional<Posts> post=service.getAllPostsByPostId(id);
		Posts like=post.get();
		long a=like.getUnlike();
		like.setUnlike(a+1);
		service.updateLike(like);
		return "Liked the post";
	}
}
