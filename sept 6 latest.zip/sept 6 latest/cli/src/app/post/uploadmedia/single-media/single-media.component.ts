import { Component, OnInit } from '@angular/core';

import { HttpEventType, HttpResponse } from '@angular/common/http';
import { PostService } from '../../post.service';
import { Router } from '@angular/router';
import { User } from 'src/app/user/user';
import { UserService } from 'src/app/user/user.service';


@Component({
  selector: 'app-single-media',
  templateUrl: './single-media.component.html',
  styleUrls: ['./single-media.component.css']
})
export class SingleMediaComponent implements OnInit {
  fileData: File = null;
  title: String;
  description: String;
  tags: String;
  userId
  user: User

  progress: { percentage: number } = { percentage: 0 };
  constructor(private postService: PostService, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    } else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
        },
        error => console.log(error)
      )
    }
  }

  createUser(user: User) {
    this.user = user
  }

  selectFile(event) {
    this.fileData = <File>event.target.files[0];
  }

  onSubmit() {
    this.progress.percentage = 0;
    this.postService.uploadPost(this.userId, this.fileData, this.title, this.description).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.progress.percentage = Math.round(100 * event.loaded / event.total);
      } else if (event instanceof HttpResponse) {
        console.log('File is completely uploaded!');
        this.router.navigate(['/homepage'])
      }
    });

    this.fileData = undefined;
  }
}
