import { User } from '../user/user';

export class Post {
    public  
    id:number;
    userid:User;
    image:String;
    liked:number;
    unlike:number;
    comment:String;
    title:String;
    description:String;
}
