import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { PostService } from '../post.service';
import { Observable } from 'rxjs';
import { Post } from '../post';

@Component({
  selector: 'app-media-details',
  templateUrl: './media-details.component.html',
  styleUrls: ['./media-details.component.css']
})
export class MediaDetailsComponent implements OnInit {
  id: number;
  post: Post;
  valid: boolean = false;
  showlike=true
  showunlike=true
  constructor(private route: ActivatedRoute, private postService: PostService) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id']
    this.route.params.subscribe(
      (param: Params) => {
        this.id = +param['id']
      }
    )
    this.detailsInit();
  }
  detailsInit() {
    this.postService.getPostsByPostId(this.id).subscribe(
      (post: Post) => {
        this.postCreate(post)
      },
      error => console.log(error)
    )

  }

  postCreate(post: Post) {
    this.post = post
    this.valid = true
  }

  onLike(id: number) {
    this.postService.like(id).subscribe(
      (data) => {
        console.log(data)
        this.detailsInit()
        this.showlike=false
      },
      error => console.log(error)
    )
  }

  onUnlike(id: number) {
    this.postService.unlike(id).subscribe(
      (data) => {
        console.log(data)
        this.detailsInit()
        this.showunlike=false
      },
      error => console.log(error)
    )
  }
}
