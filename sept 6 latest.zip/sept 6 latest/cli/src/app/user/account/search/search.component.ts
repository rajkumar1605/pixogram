import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../../user.service';
import { User } from '../../user';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { FollowService } from 'src/app/follow/follow.service';
import { Follow } from 'src/app/follow/follow';

import { Block } from 'src/app/block/block';
import { BlockService } from 'src/app/block/block.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  showsearch: boolean = false
  user: User[] = [] //this contains all the users in users db
  filteredUser: User[] = [] //contains all the users that current user has not followed yet
  filterSearchUser: User[] = []//contains all the searched users that current user has not followed yet
  currentUser: User // current user
  searchUser: User[] = []
  userFollows: Follow[] //contains all the follows data from follow db
  follow: Follow = new Follow()
  block: Block = new Block()
  blockedUsers: Block[] = []
  filterBlockedUsers: User[] = []
  filterSearchBlockedUsers: User[] = []

  userId
  constructor(private userService: UserService, private router: Router, private followService: FollowService, private blockService: BlockService) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    }
    else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
          this.searchInit();

        },
        error => console.log(error)
      )
    }

  }
  showOrHideSearch(str: String) {
    if (str.length > 0) {
      this.showsearch = true;
      this.filteredUser = []
      this.filterSearchUser = []
      this.filterBlockedUsers = []
      return
    } else {
      this.showsearch = false;
      this.filteredUser = []
      this.filterSearchUser = []
      this.filterBlockedUsers = []
      this.searchInit()
      return
    }
  }

  createUser(user: User) {
    this.currentUser = user
    console.log(this.currentUser)
  }

  searchInit() {
    this.userService.getAllUsers().subscribe(
      (user: User[]) => {
        this.initAllUserList(user)
      }
    )
    this.followService.getAllFollowingByUserId(this.userId).subscribe(
      (data: Follow[]) => {
        this.initAllFollows(data)
        this.blockService.getAllBlockedUsers().subscribe(
          (userBlocked: Block[]) => {
            console.log(userBlocked)
            this.initBlockFilter(userBlocked)
          }
        )
      }
    );
  }


  initAllUserList(user: User[]) {
    this.user = user;
  }

  initAllFollows(data: Follow[]) {
    this.userFollows = data

    let flag = 0;

    if (this.userFollows.length != 0) {//this is for normal user filtering without search
      for (var user1 of this.user) {
        flag = 0
        for (var follow of this.userFollows) {
          if (this.currentUser.id != user1.id && user1.id == follow.followid.id) {
            flag++;
            break;
          }
        }
        if (this.currentUser.id != user1.id && flag == 0) {
          this.filteredUser.push(user1)
        }
      }
    }
    else {
      for (var user of this.user) {
        if (user.id != this.currentUser.id) {
          this.filteredUser.push(user)
        }
      }
    }

  }

  initBlockFilter(blockedUser: Block[]) {
    this.blockedUsers = blockedUser
    let count = 0;
    if (this.blockedUsers.length != 0) {
      for (var user of this.filteredUser) {
        console.log("as")
        count = 0
        for (var block of this.blockedUsers) {
          if ( user.id == block.blockid.id ) {

            console.log("User id" + this.userId + "=== Block ID" + block.blockid.id)
            count++;
            break;

          }
        }
        if (count == 0) {

          this.filterBlockedUsers.push(user)
        }
      }
    } else {
      for (var user of this.filteredUser) {
        if (user.id != this.currentUser.id) {
          this.filterBlockedUsers.push(user)
        }
      }
    }
  }

  onSearch(form: NgForm) {
    this.userService.getUserByName(form.value.search).subscribe(
      (user: User[]) => {
        this.initSearchFilterUser(user)

      }
    );
    this.showsearch = true
  }

  initSearchFilterUser(user: User[]) {
    this.filteredUser = []
    this.filterSearchUser = []
    this.searchUser = user;

    let cnt = 0
    //filtering user when searched
    if (this.userFollows.length != 0) {
      for (var user2 of this.searchUser) {
        cnt = 0
        for (var follow of this.userFollows) {
          if (this.currentUser.id != user2.id && user2.id == follow.followid.id) {
            cnt++;
            break;
          }
        }
        if (this.currentUser.id != user2.id && cnt == 0) {
          this.filterSearchUser.push(user2)
        }
      }
    }
    else {
      for (var user2 of this.searchUser) {
        if (user2.id != this.currentUser.id) {
          this.filterSearchUser.push(user2)
        }
      }
    }

    //filtering search for blocked users
    let count = 0;
    if (this.blockedUsers.length != 0) {
      for (var user3 of this.filterSearchUser) {
        console.log("as")
        count = 0
        for (var block of this.blockedUsers) {
          if (user3.id == block.blockid.id) {

            console.log("User id" + this.userId + "=== Block ID" + block.blockid.id)
            count++;
            break;

          }
        }
        if (count == 0) {

          this.filterSearchBlockedUsers.push(user3)
        }
      }
    } else {
      for (var user3 of this.filteredUser) {
        if (user3.id != this.currentUser.id) {
          this.filterSearchBlockedUsers.push(user3)
        }
      }
    }
  }

  onFollow(followuser: User) {


    this.follow.userid = this.currentUser
    this.follow.followid = followuser
    this.followService.follows(this.follow).subscribe(
      (data) => {
        this.filteredUser = []
        this.filterSearchUser = []
        this.filterBlockedUsers = []
        this.searchInit()
        this.showsearch = false

      },
      error => console.log(error)
    )

  }

  onBlock(blockUser: User) {
    this.block.userid = this.currentUser
    this.block.blockid = blockUser
    this.blockService.block(this.block).subscribe(
      (data) => {
        this.filteredUser = []
        this.filterSearchUser = []
        this.filterBlockedUsers = []
        this.searchInit()
        this.showsearch = false
      },
      error => console.log(error)
    )
  }

}
