import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from '../user/user';
import { UserService } from '../user/user.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  user: User = new User();
  validPass: boolean;
  validUsername: boolean = true;

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
  }

  onSubmit(form: NgForm) {
    this.user.name = form.value.name;
    this.user.email = form.value.email;
    this.user.password = form.value.password;
    this.userService.signupUser(this.user).subscribe(
      (data: User) => {
        this.router.navigate(['/']);
      },
      error => console.log(error)
    )
    this.user = new User()
    form.reset();
  }

  checkUserName(name: String) {
    this.userService.checkUsername(name).subscribe(
      (data: number) => {
        if (data == 0) {
          console.log("already taken")
          this.validUsername = false;
        }
        if (data == 1) {
          console.log("valid username")
          this.validUsername = true;
        }
      },
      error => console.log(error)
    )
  }

  onPasswordCheck(password: String, rpassword: String) {
    if (password === rpassword) {

      this.validPass = false
    } else {

      this.validPass = true
    }
  }
}
