import { Component, OnInit } from '@angular/core';
import { Block } from 'src/app/block/block';
import { User } from 'src/app/user/user';
import { Follow } from '../follow';
import { UserService } from 'src/app/user/user.service';
import { Router } from '@angular/router';
import { FollowService } from '../follow.service';
import { BlockService } from 'src/app/block/block.service';

@Component({
  selector: 'app-following',
  templateUrl: './following.component.html',
  styleUrls: ['./following.component.css']
})
export class FollowingComponent implements OnInit {

  userId;
  block: Block = new Block()
  currentUser: User
  following: Follow[] = []
  blockedUsers: Block[] = []
  filteredfollowing: Follow[] = []

  constructor(private userService: UserService, private router: Router, private followService: FollowService, private blockService: BlockService) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    if (!this.userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['/']);
      return;
    }
    else {
      this.userService.getUserDetail(this.userId).subscribe(
        (user: User) => {
          this.createUser(user)
          this.initfollowing()
          this.initBlockedUsers()
        },
        error => console.log(error)
      )
    }
  }

  createUser(user: User) {
    this.currentUser = user;
  }

  initfollowing() {
    this.followService.getAllFollowingByUserId(this.userId).subscribe(
      (following: Follow[]) => {
        console.log(following)
        this.createfollowing(following)
      }
    )
  }
  initBlockedUsers() {
    this.blockService.getAllBlockedUsersByUserId(this.userId).subscribe(
      (blockedUser: Block[]) => {
        this.createBlockedUser(blockedUser)
      }
    )

  }

  createfollowing(following: Follow[]) {
    this.following = following;
  }
  createBlockedUser(blocked: Block[]) {
    this.blockedUsers = blocked;
    this.filteredfollowing = []
    let flag = 0;

    if (this.blockedUsers.length == 0) {
     
      this.filteredfollowing.push(... this.following)
    } else {
      
      for (var user of this.following) {
        flag = 0
        for (var block of this.blockedUsers) {
          if (user.followid.id == block.blockid.id && user.followid.id != this.currentUser.id) {
            flag++;
          }
        }
        if (flag == 0 && user.followid.id != this.currentUser.id) {
          this.filteredfollowing.push(user)
        }
      }
    }
  }

  onBlock(blockUser: User) {
    this.block.userid = this.currentUser
    this.block.blockid = blockUser
    this.blockService.block(this.block).subscribe(
      (data) => {
        this.filteredfollowing = []
        this.ngOnInit()
      },
      error => console.log(error)
    )
  }

  onUnfollow(id:number){
    this.followService.unFollow(id).subscribe(
      (data)=>{
        console.log(data)
        this.filteredfollowing = []
        this.ngOnInit()
      }
    )
  }

}