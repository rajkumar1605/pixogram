package com.pixogram.PixoGram.service;

import org.springframework.stereotype.Service;

@Service
public class PostsServiceImpl implements PostsService {

}
