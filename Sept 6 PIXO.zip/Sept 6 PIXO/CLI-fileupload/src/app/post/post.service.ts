import { Injectable } from '@angular/core';
import { HttpRequest, HttpClient, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Post } from './post';

@Injectable({
  providedIn: 'root'
})
export class PostService {
 

  private post_url = "http://localhost:9531/post";

  constructor(private http: HttpClient) { }

  uploadPost(userId, file: File, title: String, desc: String): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();

    formdata.append('user', userId);
    formdata.append('file', file);
    formdata.append('title', <string>title);
    formdata.append('desc', <string>desc);


    const req = new HttpRequest('POST', "http://localhost:9531/post/upload", formdata, {
      reportProgress: true,
      responseType: 'text'
    });

    return this.http.request(req);
  }

  getPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(`${this.post_url}/all`)
  }

  getPostsById(userId:number): Observable<Post[]> {
    return this.http.get<Post[]>(`${this.post_url}/${userId}`)
  }

  getPostsByPostId(postId:number): Observable<Post> {
    console.log(postId+"postid")
    return this.http.get<Post>(`${this.post_url}/post/${postId}`)
  }
}
