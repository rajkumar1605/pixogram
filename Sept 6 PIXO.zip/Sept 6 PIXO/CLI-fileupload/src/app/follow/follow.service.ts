import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Follow } from './follow';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class FollowService {

  private follow_url = "http://localhost:9531/follow";

  constructor(private http:HttpClient) { }

  getAllFollows():Observable<Follow[]>{
return this.http.get<Follow[]>(`${this.follow_url}/all`)
  }

  follows(follow:Follow):Observable<number>{
return this.http.post<number>(`${this.follow_url}/follow`,follow)
  }

  unFollow(unfollowUser:number):Observable<any>{
    return this.http.delete(`${this.follow_url}/delete/${unfollowUser}`, { responseType: 'text' })
  }

  getAllFollowersByUserId(userId:number):Observable<Follow[]>{
    return this.http.get<Follow[]>(`${this.follow_url}/${userId}`)
  }

  getAllFollowingByUserId(userId:number):Observable<Follow[]>{
    return this.http.get<Follow[]>(`${this.follow_url}/following/${userId}`)
  }
}
