package com.pixogram.PixoGram.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.PixoGram.model.Block;

import com.pixogram.PixoGram.service.BlockService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/block")
public class BlockController {

	@Autowired
	BlockService service;
	
	//fetching all blocked users
	@GetMapping(value="/all")
	public List<Block> getAllBlocks(){
		System.out.println("fetching all the blocked user details");
		List<Block> block=new ArrayList<Block>();
		service.getAllBlocks().forEach(block::add);
		return block;
	}
	
	//blocking user
	@PostMapping(value="/block")
	public long blockUser(@RequestBody Block block) {
		System.out.println("blocking user");
		Block blocked=service.blockUser(block);
		return blocked.getBlockid().getId();
	}
	
	//getAllBlockedByuserID
	@GetMapping(value="/{userId}")
	public List<Block> getAllBlockedByUserId(@PathVariable("userId") long id){
		System.out.println("fetching all users blocked by userid");
		List<Block> blocked=new ArrayList<>();
		service.getBlockedByUserId(id).forEach(blocked::add);
		return blocked;
	}
	
	//unblock user
	@DeleteMapping(value="/{id}")
	public String unBlock(@PathVariable("id") long id) {
		System.out.println("unblocking the user");
		service.unBlock(id);
		return "User unblocked";
	}
}
