package com.pixogram.PixoGram.service;

import java.util.List;

import com.pixogram.PixoGram.model.Block;

public interface BlockService {

	List<Block> getAllBlocks();

	Block blockUser(Block block);

	List<Block> getBlockedByUserId(long id);

	void unBlock(long id);

}
